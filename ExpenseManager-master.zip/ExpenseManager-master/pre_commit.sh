./gradlew testDebug && ./gradlew cC
