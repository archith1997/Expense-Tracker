package ajitsingh.com.expensemanager.view;

public interface AddCategoryView {
  String getCategory();

  void displayError();
}
